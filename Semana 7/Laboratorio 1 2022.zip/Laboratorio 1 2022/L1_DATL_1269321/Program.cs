﻿using System;

namespace L1_DATL_1269321
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese su nombre: ");
            string nombre = Console.ReadLine();
            
            Console.WriteLine("Hola mundo");
            Console.WriteLine("Soy " + nombre);

            /* comentarios */

            Console.Write("Hola mundo ");
            Console.Write("Soy " + nombre);

            Console.ReadKey();
        }
    }
}
