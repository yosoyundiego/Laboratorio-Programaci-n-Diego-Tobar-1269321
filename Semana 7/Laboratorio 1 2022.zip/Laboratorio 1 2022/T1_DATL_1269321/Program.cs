﻿using System;

namespace T1_DATL_1269321
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");
            Console.WriteLine();

            string sNombre, sEdad, sCarrera, sCarne;

            Console.WriteLine("Ingrese su Nombre: ");
            sNombre= Console.ReadLine();

            Console.WriteLine("Ingrese su Edad: ");
            sEdad = Console.ReadLine();

            Console.WriteLine("Ingrese su Carrera: ");
            sCarrera = Console.ReadLine();

            Console.WriteLine("Ingrese su Carné: ");
            sCarne = Console.ReadLine();
            Console.WriteLine();

            Console.WriteLine("Nombre: " + sNombre);
            Console.WriteLine("Edad: " + sEdad);
            Console.WriteLine("Carrera: " + sCarrera);
            Console.WriteLine("Carné: " + sCarne);
            Console.WriteLine();

            Console.WriteLine("Soy " + sNombre + ", tengo " + sEdad + " años y estudio la carrera de " + sCarrera + ". Mi número de carné es: " + sCarne);

            Console.ReadKey();
        }
    }
}
