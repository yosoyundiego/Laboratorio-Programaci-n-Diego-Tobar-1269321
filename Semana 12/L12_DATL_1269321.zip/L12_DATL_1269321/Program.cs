﻿using System;
using System.Linq;

namespace L12_DATL_1269321
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] tabla1 = new int[4, 5];
            int sumaT1 = 0;

            Random numAleatorio = new Random();
            
            for(int f = 0; f < 4; f++)
            {
                for (int c = 0; c < 5; c++)
                {
                    tabla1[f, c] = numAleatorio.Next(1, 101);
                }
            }

            Console.WriteLine("Tabla 1:");
            Console.WriteLine();

            for (int f = 0; f < 4; f++)
            {
                for (int c = 0; c < 5; c++)
                {
                    Console.Write(tabla1[f, c] + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine();

            for (int f = 0; f < 4; f++)
            {
                for (int c = 0; c < 5; c++)
                {
                    sumaT1 = sumaT1 + tabla1[f, c];
                }
            }

            Console.WriteLine("La suma de todos los elementos de la tabla 1 es: " + sumaT1);
            Console.WriteLine("El promedio de los elementos de la matriz es: " + (sumaT1/tabla1.Length));
            Console.WriteLine();

            Console.ReadKey();

            int filas, columnas;
            Console.WriteLine("Ingrese el número de filas que tendrán las matrices: ");
            filas = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el número de columnas que tendrán las matrices: ");
            columnas = int.Parse(Console.ReadLine());

            int[,] matriz2 = new int[filas, columnas];
            int[,] matriz3 = new int[filas, columnas];
            int[,] matrizResultante = new int[filas, columnas];

            for (int f = 0; f < filas; f++)
            {
                for (int c = 0; c < columnas; c++)
                {
                    matriz2[f, c] = numAleatorio.Next(1, 101);
                    matriz3[f, c] = numAleatorio.Next(1, 101);
                }
            }

            Console.WriteLine("La matriz resultante de sumar ambas matrices es: ");
            Console.WriteLine();

            for (int f = 0; f < filas; f++)
            {
                for (int c = 0; c < columnas; c++)
                {
                    matrizResultante[f, c] = matriz2[f, c] + matriz3[f, c];
                    Console.Write(matrizResultante[f, c] + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine();

            Console.ReadKey();
        }
    }
}
