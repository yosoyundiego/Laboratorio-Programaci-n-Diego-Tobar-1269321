﻿using System;

namespace L10_DATL_1269321
{
    class Program
    {
        static void Main(string[] args)
        {
            string usuario, contraseña;
            bool validacion;
            int contador = 0;            

            do
            {
                Console.Write("Ingrese usuario: ");
                usuario = Console.ReadLine();
                Console.WriteLine();
                Console.WriteLine("Ingrese contraseña: ");
                contraseña = Console.ReadLine();

                validacion = validarUsuario(usuario, contraseña);

                contador++;

                if (validacion == true)
                {
                    Console.WriteLine();
                    Console.WriteLine("Se ha logueado correctamente: ");
                    contador = 3;
                }
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("No se ha logueado correctamente: ");
                    Console.WriteLine("Número de intentos: " + (contador));
                }

                Console.WriteLine();
                
            } while (contador < 3);

            Console.ReadKey();
        }

        static bool validarUsuario(string usuario, string contraseña)
        {
            bool validar = false;
            if(usuario == "usuario1" && contraseña == "asdasd")
            {
                validar = true;
            }
            
            return validar;
        }
    }
}
